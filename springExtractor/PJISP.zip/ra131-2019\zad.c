// Todor Belic RA131-2019
#include <stdio.h>
#include <math.h>

int main() {
      
    int n,m,i;
    float b,suma = 0;
     
	do { 
	    printf("Unesi prvi broj: ");
	    scanf("%d", &n);
	} while ( n <= 0);

        do {
            printf("Unesi drugi broj: ");
            scanf("%d", &m);
            
        } while (m <= n);
        
        for(i=n; i<=m; i++) {
           
           if (i%2 == 0) 
    
           
           suma = suma + pow(pow(i,2) , 1/3);
           
         
           
           else if
           
           suma = suma - sqrt(pow(i,3));
        
           if(i == n+2)
           
           continue;
           
           if(i == n+3)
           {
           	if(suma > 10) 
           	printf("[i-%d]Trenutna suma je: %.2f",i-n+1, suma);
                if (suma <= 10) 
           	printf("[i-%d]Trenutna suma je: %.1f",i-n+1, suma);
           
           }  
         
          
        }
       printf("\n"); 
       printf("Uneti broj ");
       scanf("%f", &b);        
       
       if(b > suma) 
       
       printf("Ukupna suma je manja od broja %.3f", b);
       
       else if( b = suma)
       
       printf("Ukupna suma je jednaka broju %.3f", b);
       
       else 
       
       printf("Ukupna suma je veca od broja %.3f", b);
       printf("\n");









return 0;
}


